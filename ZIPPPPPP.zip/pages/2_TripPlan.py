import streamlit as st
from planner import generate_itinerary
from pdf_utils import generate_styled_pdf
from weather_api import get_weather
from dotenv import load_dotenv
import db
import re
import json
from datetime import timedelta, datetime

st.set_page_config(page_title="Your Trip Plan", page_icon="🗺️", layout="wide")
load_dotenv()

# --- CSS for subtle fade and spacing ---
st.markdown("""
<style>
.fade-in { animation: fadeIn 0.5s ease-in-out; }
@keyframes fadeIn { from {opacity: 0;} to {opacity: 1;} }
hr {border: none; border-top: 1px solid #ccc; margin: 2rem 0;}
</style>
""", unsafe_allow_html=True)

# --- Auth check ---
if "user_email" not in st.session_state or not st.session_state["user_email"]:
    st.error("🔒 Please log in or authenticate before generating your itinerary.")
    if st.button("Go to Login Page", key="login_btn"):
        st.switch_page("Roam-Genie.py")
    st.stop()

# --- Load trip details ---
trip = st.session_state.get("selected_trip") or st.session_state.get("trip_details")
if not trip:
    st.error("🧞‍♂️ No trip details found. Please go back and enter your trip info.")
    if st.button("🔙 Return to Dashboard"):
        st.switch_page("pages/3_History.py")
    st.stop()

# --- Unpack trip_data safely ---
trip_data = trip.get("trip_data", trip)
destination = trip_data.get("destination", "Unknown")
start_date = trip_data.get("start_date", "")
end_date = trip_data.get("end_date", "")
style = trip_data.get("trip_style", [])
budget_level = trip_data.get("budget_level", "medium")
currency = trip_data.get("currency", "USD")
show_weather = trip_data.get("include_weather", True)

# --- Normalize dates ---
def to_date(value):
    if hasattr(value, "strftime"):
        return value
    if isinstance(value, str):
        try:
            return datetime.strptime(value, "%Y-%m-%d").date()
        except Exception:
            return value
    return value

start_date = to_date(start_date)
end_date = to_date(end_date)

# --- Weather info ---
weather_info = get_weather(destination, start_date, end_date) if show_weather else None

# --- Generate itinerary ---
with st.spinner("Crafting your adventure... ✈️"):
    itinerary_text = generate_itinerary(trip_data, weather_info)

# --- Clean and strip unwanted sections ---
def clean_itinerary_text(text: str) -> str:
    # Remove budget sections
    text = re.sub(r"(?is)###?\s*💰.*?(?=###|$)", "", text)
    # Remove JSON code blocks
    text = re.sub(r"```json[\\s\\S]*?```", "", text)
    text = re.sub(r"```[\\s\\S]*?```", "", text)
    # Remove trailing braces or random JSON at end
    text = re.sub(r"\\{[\\s\\S]*\\}$", "", text)
    # Remove extra blank lines
    text = re.sub(r"\\n{3,}", "\\n\\n", text)
    return text.strip()

# --- Parse itinerary day-wise with separators ---
def parse_itinerary(text, start_date):
    days = []
    current_day = []
    for line in text.splitlines():
        if re.match(r"(?i)^day\\s*\\d+", line.strip()):
            if current_day:
                days.append("\\n".join(current_day).strip())
                current_day = []
        current_day.append(line)
    if current_day:
        days.append("\\n".join(current_day).strip())
    # Format into day blocks with spacing
    formatted = "\\n\\n---\\n\\n".join(days)
    return formatted.strip()

cleaned_text = clean_itinerary_text(itinerary_text)
final_itinerary = parse_itinerary(cleaned_text, start_date)

# --- Checklist & Safety Tips Extraction ---
def parse_checklist_and_tips_from_text(text: str):
    chk, tips = {}, []
    current_cat, in_chk, in_tips = None, False, False
    for raw in text.splitlines():
        line = raw.strip()
        if not line:
            continue
        if re.match(r"(?i)^(?:[📦🧳🎒]\\s*)?(?:travel\\s+)?packing\\s+checklist\\b", line):
            in_chk, in_tips = True, False
            continue
        if re.match(r"(?i)^(?:[🛡️]\\s*)?safety\\s+tips\\b", line):
            in_chk, in_tips = False, True
            continue
        if in_chk:
            if re.match(r"(?i)^\\*\\*.*\\*\\*$", line) or line.endswith(":"):
                current_cat = re.sub(r"^\\*\\*|\\*\\*$", "", line).rstrip(":").strip()
                chk.setdefault(current_cat, [])
                continue
            if line.startswith("-"):
                chk.setdefault(current_cat or "General", []).append(line.lstrip("- ").strip())
        if in_tips and (line.startswith("-") or line.startswith("•")):
            tips.append(line.lstrip("-• ").strip())
    return chk, tips

# --- Fallback generator if missing ---
def generate_checklist_and_tips(trip_data, weather_info, text):
    chk, tips = parse_checklist_and_tips_from_text(text)
    if chk or tips:
        return chk, tips
    # intelligent fallback
    city = trip_data.get("destination", "your destination")
    style = ", ".join(trip_data.get("trip_style", [])) or "mixed style"
    weather = str(weather_info or "")
    chk = {
        "Essentials": ["Passport & ID", "Travel tickets", "Local currency / cards", "Reusable water bottle"],
        "Clothing": [f"Comfortable clothes for {weather.lower()}", "Walking shoes", "Light jacket or raincoat"],
        "Electronics": ["Phone & charger", "Power adapter", "Camera / GoPro"]
    }
    tips = [
        f"Keep an offline map of {city}.",
        "Avoid carrying large sums of cash.",
        f"Check weather updates — {weather.lower()}.",
        "Respect local customs and dress codes.",
        "Keep emergency numbers saved."
    ]
    return chk, tips

checklist, safety_tips = generate_checklist_and_tips(trip_data, weather_info, itinerary_text)

# --- Save cleaned itinerary only (no JSON/budget) ---
db.init_db()
db.add_itinerary(st.session_state["user_email"], trip_data, cleaned_text, checklist, safety_tips)

# --- Page Header ---
st.title("🗓️ Your Travel Itinerary")
st.markdown(f"**Destination:** {destination}  \n**Dates:** {start_date} to {end_date}  \n**Travel Style:** {', '.join(style)}")

# --- Actions ---
col1, col2 = st.columns(2)
with col1:
    if st.button("✏️ Edit Trip"):
        st.switch_page("pages/1_TripDetails.py")
with col2:
    pdf_bytes = generate_styled_pdf(trip_data, cleaned_text, checklist, safety_tips)
    safe_name = "".join(ch for ch in destination if ch.isalnum() or ch in (" ", "_", "-")).strip().replace(" ", "_")
    st.download_button(
        "📄 Download Itinerary PDF",
        pdf_bytes,
        file_name=f"{safe_name}_Itinerary.pdf",
        mime="application/pdf"
    )

# --- Itinerary Display ---
st.markdown("## 🗓️ Itinerary")
st.markdown(f'<div class="fade-in">{final_itinerary}</div>', unsafe_allow_html=True)

# --- Packing Checklist ---
if checklist:
    st.markdown("## 🎒 Packing Checklist")
    for category, items in checklist.items():
        st.markdown(f"**{category}**")
        for item in items:
            st.markdown(f"- {item}")
        st.markdown("")  # spacing

# --- Safety Tips ---
if safety_tips:
    st.markdown("## 🛡️ Safety Tips")
    for tip in safety_tips:
        st.markdown(f"🛡️ {tip}")
