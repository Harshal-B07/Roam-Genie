from fpdf import FPDF
from typing import Dict, Any, List
from datetime import date, datetime
import os
import unicodedata
import re


def sanitize_text(text: str) -> str:
    """Sanitize text for PDF generation by removing problematic characters."""
    if not isinstance(text, str):
        text = str(text)
    
    # Remove control characters and emojis
    cleaned = []
    for ch in text:
        code = ord(ch)
        if code > 0xFFFF:  # Remove emojis and high-plane characters
            continue
        if unicodedata.category(ch)[0] == "C" and ch not in ("\n", "\t"):
            continue
        cleaned.append(ch)
    
    return "".join(cleaned)


def generate_pdf(trip: Dict[str, Any], itinerary_text: str, checklist=None, safety_tips=None) -> bytes:
    """
    Generate a styled PDF itinerary using FPDF.
    Compatible with existing project structure.
    """
    checklist = checklist or {}
    safety_tips = safety_tips or []

    # Extract trip info
    destination = trip.get("destination", "Unknown")
    start_date = trip.get("start_date", "")
    end_date = trip.get("end_date", "")
    trip_style = trip.get("trip_style", "")
    budget_amount = trip.get("budget_amount", "")
    budget_level = trip.get("budget_level", "")
    num_people = trip.get("num_people", "")
    travel_modes = trip.get("travel_modes", [])

    # Normalize dates
    if isinstance(start_date, date):
        start_date = start_date.strftime("%d %b %Y")
    elif isinstance(start_date, str):
        try:
            dt = datetime.strptime(start_date, "%Y-%m-%d")
            start_date = dt.strftime("%d %b %Y")
        except:
            pass
            
    if isinstance(end_date, date):
        end_date = end_date.strftime("%d %b %Y")
    elif isinstance(end_date, str):
        try:
            dt = datetime.strptime(end_date, "%Y-%m-%d")
            end_date = dt.strftime("%d %b %Y")
        except:
            pass

    # Initialize PDF
    pdf = FPDF()
    pdf.set_auto_page_break(auto=True, margin=15)
    pdf.add_page()

    # Try to load DejaVu fonts
    font_path = "fonts/DejaVuSans.ttf"
    bold_font_path = "fonts/DejaVuSans-Bold.ttf"
    
    if os.path.exists(font_path) and os.path.exists(bold_font_path):
        try:
            pdf.add_font("DejaVu", "", font_path, uni=True)
            pdf.add_font("DejaVu", "B", bold_font_path, uni=True)
            font_name = "DejaVu"
        except:
            font_name = "Arial"
    else:
        font_name = "Arial"

    # Cover page
    pdf.set_font(font_name, "B", 24)
    pdf.set_text_color(0, 0, 100)
    pdf.cell(0, 15, sanitize_text(destination), ln=True, align="C")
    
    pdf.set_font(font_name, "", 14)
    pdf.set_text_color(50, 50, 50)
    pdf.cell(0, 10, sanitize_text(f"{start_date} to {end_date}"), ln=True, align="C")
    
    pdf.ln(20)
    pdf.set_font(font_name, "", 12)
    pdf.multi_cell(0, 8, sanitize_text("Your personalized trip itinerary awaits!"), align="C")
    
    pdf.add_page()

    # Trip Overview
    pdf.set_font(font_name, "B", 16)
    pdf.set_text_color(0, 102, 204)
    pdf.cell(0, 10, "Trip Overview", ln=True)
    
    pdf.set_font(font_name, "", 12)
    pdf.set_text_color(0, 0, 0)
    pdf.multi_cell(0, 8, sanitize_text(f"Destination: {destination}"))
    pdf.multi_cell(0, 8, sanitize_text(f"Dates: {start_date} to {end_date}"))
    pdf.multi_cell(0, 8, sanitize_text(f"Style: {trip_style}"))
    pdf.multi_cell(0, 8, sanitize_text(f"Budget: ₹{budget_amount} ({budget_level})"))
    pdf.multi_cell(0, 8, sanitize_text(f"Travel modes: {', '.join(map(str, travel_modes))}"))
    pdf.multi_cell(0, 8, sanitize_text(f"Travellers: {num_people}"))
    pdf.ln(10)

    # Daily Itinerary
    pdf.set_font(font_name, "B", 16)
    pdf.set_text_color(0, 102, 204)
    pdf.cell(0, 10, "Daily Itinerary", ln=True)
    pdf.set_text_color(0, 0, 0)
    pdf.ln(5)

    # Parse itinerary into day blocks
    lines = [ln for ln in (itinerary_text or "").splitlines() if ln.strip()]
    blocks, current = [], []
    for ln in lines:
        if ln.lower().startswith("day "):
            if current:
                blocks.append(current)
            current = [ln]
        else:
            current.append(ln)
    if current:
        blocks.append(current)

    # Build each day
    for block in blocks:
        if not block:
            continue
        pdf.set_font(font_name, "B", 13)
        pdf.set_text_color(30, 30, 120)
        pdf.cell(0, 8, sanitize_text(block[0]), ln=True)
        
        pdf.set_font(font_name, "", 11)
        pdf.set_text_color(0, 0, 0)
        for body_line in block[1:]:
            if body_line.strip():
                pdf.multi_cell(0, 6, sanitize_text(body_line))
        pdf.ln(4)

    # Packing Checklist
    if checklist:
        pdf.add_page()
        pdf.set_font(font_name, "B", 16)
        pdf.set_text_color(0, 102, 204)
        pdf.cell(0, 10, "Packing Checklist", ln=True)
        pdf.set_text_color(0, 0, 0)
        pdf.set_font(font_name, "", 11)
        
        for cat, items in checklist.items():
            pdf.set_font(font_name, "B", 12)
            pdf.cell(0, 8, sanitize_text(f"{cat}:"), ln=True)
            pdf.set_font(font_name, "", 11)
            for item in items:
                pdf.multi_cell(0, 6, sanitize_text(f"• {item}"))
            pdf.ln(3)

    # Safety Tips
    if safety_tips:
        pdf.add_page()
        pdf.set_font(font_name, "B", 16)
        pdf.set_text_color(0, 102, 204)
        pdf.cell(0, 10, "Safety Tips", ln=True)
        pdf.set_text_color(0, 0, 0)
        pdf.set_font(font_name, "", 11)
        
        for tip in safety_tips:
            pdf.multi_cell(0, 6, sanitize_text(f"• {tip}"))
            pdf.ln(2)

    # Return PDF bytes
    out = pdf.output(dest="S")
    if isinstance(out, bytearray):
        return bytes(out)
    if isinstance(out, bytes):
        return out
    if isinstance(out, str):
        return out.encode("latin1", "ignore")
    return bytes(out)


def generate_styled_pdf(trip: Dict[str, Any], itinerary_text: str, checklist: Dict[str, List[str]] = None, safety_tips: List[str] = None) -> bytes:
    """Main styled PDF generation function."""
    return generate_pdf(trip, itinerary_text, checklist, safety_tips)


def save_styled_pdf(trip: Dict[str, Any], itinerary_text: str, checklist=None, safety_tips=None, folder="itineraries") -> str:
    """Save styled PDF to disk and return filename."""
    os.makedirs(folder, exist_ok=True)
    dest = trip.get("destination", "Trip").replace(" ", "_")
    filename = os.path.join(folder, f"{dest}_Itinerary.pdf")
    
    pdf_bytes = generate_pdf(trip, itinerary_text, checklist, safety_tips)
    with open(filename, "wb") as f:
        f.write(pdf_bytes)
    
    return filename