from datetime import datetime

def full_trip_prompt(trip, weather_parsed, budget_per_day):
    # Ensure dates are datetime.date objects
    start = trip["start_date"]
    end = trip["end_date"]

    if isinstance(start, str):
        start = datetime.strptime(start, "%Y-%m-%d").date()
    if isinstance(end, str):
        end = datetime.strptime(end, "%Y-%m-%d").date()

    nights = (end - start).days
    currency = trip.get("currency", "USD")
    destination = trip["destination"].split(",")[0].strip()

    return f"""
You are an expert travel planner and well-travelled blogger who creates realistic, inspiring itineraries that feel handcrafted.

Create a customized trip titled:  
**Your {destination} Adventure**  
_A handcrafted journey through culture, charm, and hidden gems._

Plan a trip from {trip['source']} to {trip['destination']} for {trip['num_people']} people.  
Trip dates: {start} to {end} ({nights} nights)  
Weather snapshot: {weather_parsed}  
Preferred travel modes: {', '.join(trip['travel_modes'])}  
Trip style: {', '.join(trip['trip_style'])}  
Budget level: {trip['budget_level']} (approx. {budget_per_day} {currency} per day)

Preferences:  
- Tone: friendly, engaging, and written like a local sharing insider knowledge  
- Dietary: {trip.get('dietary_pref', 'none')}  
- Must-include: {trip.get('must_include_list', 'none')}  
- Avoid: {trip.get('avoid_list', 'none')}

Local logistics:  
- Typical opening hours: {trip.get('opening_hours_hint', 'N/A')}  
- Known closures: {trip.get('closures_hint', 'N/A')}  
- Sunrise/Sunset: {trip.get('sunrise', 'N/A')} / {trip.get('sunset', 'N/A')}  
- Suggested neighborhood clustering: {trip.get('neighborhood_clusters', 'N/A')}

---

### 🧭 Structure your response using **exactly these headings in this order**:
Do not rename, omit, or merge them.

1. **### 🗓️ Itinerary**  
   - Include a clear per-day breakdown (Day 1, Day 2, etc.)
   - Each day must include Morning, Afternoon, and Evening sections with time ranges.
   - Each block: 1 popular anchor + 1 hidden gem (when possible)
   - Include local food recommendations respecting dietary preferences.
   - Logical flow (minimize travel time).
   - End each day with a “Daily Travel Tip”.

2. **### 🎒 Packing Checklist**  
   - Must have at least 3 categories (e.g., Essentials, Weather Gear, Electronics, etc.)
   - Each category must have 3–6 bullet points.
   - Tailor suggestions to the trip’s weather, duration, and activities.

3. **### 🛡️ Safety Tips**  
   - Include 5–10 concise, destination-specific tips.
   - Cover local etiquette, health/safety, and transit or scam warnings.

---

### 💰 Budget Note  
Provide a per-day cost breakdown in {currency}:  
- Accommodation, Food, Transport, Activities  
- Include a daily subtotal and total trip estimate.

---

### 🧩 Output Format:
Use clean Markdown formatting and at the end, include a JSON code block like this:

```json
{{
  "summary": "...",
  "days": [
    {{
      "date": "YYYY-MM-DD",
      "theme": "...",
      "blocks": [...],
      "daily_tip": "...",
      "costs": {{
        "accommodation": 0,
        "food": 0,
        "transport": 0,
        "activities": 0
      }}
    }}
  ],
  "checklist": {{
    "Essentials": ["..."],
    "Electronics": ["..."]
  }},
  "safety_tips": ["...", "..."],
  "totals": {{
    "trip_total_{currency.lower()}": 0
  }}
}}

✅ Always include both the “🎒 Packing Checklist” and “🛡️ Safety Tips” sections — never omit them.
"""

def day_edit_prompt(trip, weather_parsed, prev_day_content, next_day_content, day_num, day_date, trip_summary):
    currency = trip.get("currency", "USD")
    return f"""
You are an expert travel planner and well-travelled blogger.
You will regenerate ONLY one day of an existing trip itinerary.

Trip context:
From {trip['source']} to {trip['destination']} for {trip['num_people']} people
Trip dates: {trip['start_date']} to {trip['end_date']}
Weather snapshot: {weather_parsed}
Preferred travel modes: {', '.join(trip['travel_modes'])}
Trip style: {', '.join(trip['trip_style'])}
Budget level: {trip['budget_level']} (approx. {trip.get('budget_per_day', 'N/A')} {currency} per day)

Existing itinerary summary:
{trip_summary}

Previous day’s plan:
{prev_day_content}

Next day’s plan:
{next_day_content}

Regenerate Day {day_num} ({day_date}) with:

Morning / Afternoon / Evening blocks with time ranges

Each block: 1 popular anchor + 1 hidden gem (when possible)

Include local food recs (respect dietary prefs)

Logical flow from previous day to next day

No repeating venues from any other day in the trip

End with a one-line “Daily Travel Tip”

Keep tone/style consistent with the rest of the trip

Formatting:

Markdown for the day’s plan (same style as full itinerary)

At the end, include a JSON block for this day only: date, theme, blocks, daily_tip, costs
"""
