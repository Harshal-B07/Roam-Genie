import os
from dotenv import load_dotenv
from datetime import datetime
import google.generativeai as genai

# --- Load environment variables ---
load_dotenv()

GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-2.5-flash-lite")
GEMINI_TIMEOUT = int(os.getenv("GEMINI_TIMEOUT", "45"))

# --- Configure Gemini client ---
genai.configure(api_key=GEMINI_API_KEY)

# --- Verify available models and fallback if needed ---
try:
    available_models = [m.name for m in genai.list_models()]
    if GEMINI_MODEL not in available_models:
        print(f"⚠ Model '{GEMINI_MODEL}' not found. Falling back to 'gemini-2.5-flash-lite'")
        GEMINI_MODEL = "gemini-2.5-flash-lite"
except Exception as e:
    print(f"⚠ Failed to list models: {str(e)}")
    GEMINI_MODEL = "gemini-2.5-flash-lite"

model = genai.GenerativeModel(GEMINI_MODEL)

# --- Debug logging ---
print(f"🔧 Using Gemini model: {GEMINI_MODEL}")
api_key_prefix = (GEMINI_API_KEY[:8] + "...") if GEMINI_API_KEY else "(missing)"
print(f"🔐 API key prefix: {api_key_prefix}")


def generate_itinerary(trip: dict, weather_info=None) -> str:
    """
    Generate a travel itinerary using Google Gemini.
    Ensures that Packing Checklist and Safety Tips sections are ALWAYS included.
    """

    # --- Custom prompt short-circuit ---
    custom_prompt = trip.get("custom_prompt")
    if custom_prompt:
        try:
            response = model.generate_content(custom_prompt)
            return response.text.strip()
        except Exception as e:
            return f"❌ Failed to generate itinerary: {str(e)}"

    # --- Extract inputs ---
    source = trip.get("source", "")
    destination = trip.get("destination", "")
    num_people = trip.get("num_people", 1)
    start_date = trip.get("start_date", "")
    end_date = trip.get("end_date", "")
    travel_modes = trip.get("travel_modes", [])
    trip_style = trip.get("trip_style", [])
    budget_level = trip.get("budget_level", "")
    budget_amount = trip.get("budget_amount", 0.0)
    weather_text = str(weather_info or "")

    # --- Convert dates to date objects ---
    if isinstance(start_date, str):
        try:
            start_date_obj = datetime.strptime(start_date, "%Y-%m-%d").date()
        except:
            start_date_obj = datetime.today().date()
    else:
        start_date_obj = start_date

    if isinstance(end_date, str):
        try:
            end_date_obj = datetime.strptime(end_date, "%Y-%m-%d").date()
        except:
            end_date_obj = start_date_obj
    else:
        end_date_obj = end_date

    # --- Trip length & budget per day ---
    trip_length = max(1, (end_date_obj - start_date_obj).days + 1)
    try:
        budget_value = float(budget_amount)
    except (ValueError, TypeError):
        budget_value = 0.0
    budget_per_day = round(budget_value / trip_length, 2)

    # --- Ensure travel_modes/trip_style are lists ---
    if not isinstance(travel_modes, list):
        travel_modes = [str(travel_modes)]
    if isinstance(trip_style, str):
        trip_style = [trip_style]

    # --- Build prompt ---
    from gpt_prompt import full_trip_prompt
    prompt = full_trip_prompt(
        {
            "source": source,
            "destination": destination,
            "num_people": num_people,
            "start_date": start_date_obj,
            "end_date": end_date_obj,
            "travel_modes": travel_modes,
            "trip_style": trip_style,
            "budget_level": budget_level,
        },
        weather_text,
        budget_per_day
    )

    # --- Generate content with Gemini ---
    try:
        response = model.generate_content(prompt)
        text = response.text.strip()

        # 🧠 Fallback: ensure both sections exist (Packing Checklist + Safety Tips)
        missing_checklist = "Packing Checklist" not in text
        missing_safety = "Safety Tips" not in text

        if missing_checklist or missing_safety:
            print("⚠️ Gemini skipped a section — generating fallback content...")
            fallback_parts = []

            if missing_checklist:
                fallback_parts.append("### 🎒 Packing Checklist")
            if missing_safety:
                fallback_parts.append("### 🛡️ Safety Tips")

            extra_prompt = f"""
You forgot one or more sections in the travel itinerary for {destination}.
Provide only the missing sections below, formatted in Markdown.
Each must have at least 5 bullet points.

{os.linesep.join(fallback_parts)}
            """

            extra_response = model.generate_content(extra_prompt)
            text += f"\n\n{extra_response.text.strip()}"

        return text

    except Exception as e:
        return f"❌ Failed to generate itinerary: {str(e)}"
